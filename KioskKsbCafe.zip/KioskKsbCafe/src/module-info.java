/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module KioskKsbCafe {
}