package com.ksb.kiosk.cafe;

import com.ksb.util.Cw;

public class ProcMenuDessert {
public static void run() {
		
		for(Product p:KioskObj.products) {	
			Cw.wn(p.name);
		}
		yy:while(true) {
			Cw.wn("[1.마카롱/2.케이크/x.이전메뉴로]");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				Cw.wn(KioskObj.products.get(2).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(2)));
				break;
			case "2":
				Cw.wn(KioskObj.products.get(3).name+" 선택됨");
				KioskObj.basket.add(new Order(KioskObj.products.get(3)));
				break;
			case "x":
				Cw.wn("이전 메뉴 이동");
				break yy;
			}
		}
	}
}
