package com.ksb.kiosk.cafe;

public class Order {

	public Product selectedProduct;
	public int optionHotCold = 0;

	String k;
	
	
	public Order(Product selectedProduct) {
		this.selectedProduct = selectedProduct;
	}

	public Order(Product selectedProduct, int optionHotCold) {
		this.selectedProduct = selectedProduct;
		this.optionHotCold = optionHotCold;
		
		if(optionHotCold==1) {
			k="Hot"+selectedProduct.name;
		}
		if(optionHotCold==2) {
			k="Ice"+selectedProduct.name;
		}
		
	}
}
