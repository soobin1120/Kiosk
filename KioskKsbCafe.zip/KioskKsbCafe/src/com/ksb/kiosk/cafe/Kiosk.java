package com.ksb.kiosk.cafe;

import java.util.ArrayList;

import com.ksb.util.Cw;

public class Kiosk {
	void run() {
		KioskObj.productLoad();
		Disp.title();
		xx:while(true) {
			Cw.wn("주문 번호 입력[1.음료선택/2.디저트선택/e.프로그램종료]:");
			KioskObj.cmd = KioskObj.sc.next();
			switch(KioskObj.cmd) {
			case "1":
				ProcMenuDrink.run();
				break;
			case "2":
				ProcMenuDessert.run();
				break;
			case "e":
				Cw.wn("장바구니에 담긴 상품 갯수:"+KioskObj.basket.size());
				int sum = 0;
				for(Order o:KioskObj.basket) {
					sum = sum + o.selectedProduct.price;
				}
				Cw.wn("계산하실 금액은 :"+sum+"원 입니다.");
				
				Cw.wn("====================");
				for(Order o:KioskObj.basket) {
//				
					if(o.selectedProduct.name.equals("아메리카노")) {
						Cw.wn(o.k);
					}
					else if(o.selectedProduct.name.equals("라떼")) {
						Cw.wn(o.k);
					}
						
					else  {
						Cw.wn(o.selectedProduct.name);
					}
				}
				Cw.wn("====================");
				Cw.wn("프로그램종료");
				break xx;
			}
		}		
	}
}
